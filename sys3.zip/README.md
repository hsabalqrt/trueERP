\*\*

## Sys3

<p align="center">
<img src="1.png" alt="Build Status">
</p>
\*\*

**What is new**

1.  **Card stats** added to **Clients** page.

**Important cmd:**
php artisan view:clear
php artisan optimize:clear

-   [ ]

## Create a Custom Widget

php artisan make:filament-widget ClientCount --resource=ClientResource

https://chatgpt.com/share/685ad10c-c258-8007-a837-90925799deaf
