<div
    <?php echo e($attributes
            ->merge([
                'id' => $getId(),
            ], escape: false)
            ->merge($getExtraAttributes(), escape: false)); ?>

>
    <?php echo e($getChildComponentContainer()); ?>

</div>
<?php /**PATH D:\أعمال اليوم\الوليد للتجارة العامة والاستيراد\sys3\vendor\filament\infolists\resources\views\components\grid.blade.php ENDPATH**/ ?>