<p
    <?php echo e($attributes->class(['fi-modal-description text-sm text-gray-500 dark:text-gray-400'])); ?>

>
    <?php echo e($slot); ?>

</p>
<?php /**PATH D:\أعمال اليوم\الوليد للتجارة العامة والاستيراد\sys3\resources\views\vendor\filament\components\modal\description.blade.php ENDPATH**/ ?>