<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('client_needs', function (Blueprint $table) {
            $table->enum('importance_level', ['عالية جداً', 'عالية', 'متوسطة', 'منخفضة'])->nullable()->after('id');

        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('client_needs', function (Blueprint $table) {
            $table->dropColumn('importance_level');
        });
    }
};
