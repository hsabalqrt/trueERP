-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 01, 2025 at 04:08 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sys3`
--

-- --------------------------------------------------------

--
-- Table structure for table `cache`
--

CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cache`
--

INSERT INTO `cache` (`key`, `value`, `expiration`) VALUES
('trueerp_cache_livewire-rate-limiter:0b9054d47166a1c454d0e6d9b6657c6fb588811e', 'i:1;', 1750784010),
('trueerp_cache_livewire-rate-limiter:0b9054d47166a1c454d0e6d9b6657c6fb588811e:timer', 'i:1750784010;', 1750784010),
('trueerp_cache_livewire-rate-limiter:3c97298e29f5599ab62395de8f7c3fe463dbd5ff', 'i:2;', 1750783701),
('trueerp_cache_livewire-rate-limiter:3c97298e29f5599ab62395de8f7c3fe463dbd5ff:timer', 'i:1750783701;', 1750783701),
('trueerp_cache_livewire-rate-limiter:a17961fa74e9275d529f489537f179c05d50c2f3', 'i:1;', 1750782487),
('trueerp_cache_livewire-rate-limiter:a17961fa74e9275d529f489537f179c05d50c2f3:timer', 'i:1750782487;', 1750782487);

-- --------------------------------------------------------

--
-- Table structure for table `cache_locks`
--

CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `added_by_user` bigint(20) UNSIGNED DEFAULT NULL,
  `updated_by_user` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `created_at`, `updated_at`, `added_by_user`, `updated_by_user`) VALUES
(1, 'صراف', '2025-05-28 23:50:45', '2025-05-28 23:50:45', NULL, NULL),
(2, 'تاجر', '2025-05-28 23:50:49', '2025-05-28 23:50:49', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `category_client_need`
--

CREATE TABLE `category_client_need` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `client_need_id` bigint(20) UNSIGNED NOT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `category_client_need`
--

INSERT INTO `category_client_need` (`id`, `client_need_id`, `category_id`, `created_at`, `updated_at`) VALUES
(1, 1, 2, NULL, NULL),
(2, 2, 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `category_designer`
--

CREATE TABLE `category_designer` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `designer_id` bigint(20) UNSIGNED NOT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `category_designer`
--

INSERT INTO `category_designer` (`id`, `designer_id`, `category_id`, `created_at`, `updated_at`) VALUES
(1, 1, 1, NULL, NULL),
(2, 1, 2, NULL, NULL),
(3, 2, 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE `clients` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `company` varchar(255) NOT NULL,
  `client_name` varchar(255) DEFAULT NULL,
  `location_id` bigint(20) UNSIGNED DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `contact_number` varchar(255) DEFAULT NULL,
  `date_of_subscription` timestamp NOT NULL DEFAULT current_timestamp(),
  `currency_id` bigint(20) UNSIGNED NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `marketing_amount` decimal(10,2) DEFAULT NULL,
  `subscription_type` enum('monthly','annual') NOT NULL DEFAULT 'monthly',
  `payment_type` enum('advance','deferred') NOT NULL DEFAULT 'advance',
  `notified_at` timestamp NULL DEFAULT NULL,
  `suspension_days` int(11) DEFAULT NULL,
  `is_credit_allowed` tinyint(1) NOT NULL DEFAULT 0,
  `suspended_at` timestamp NULL DEFAULT NULL,
  `package_id` bigint(20) UNSIGNED NOT NULL,
  `client_need_id` bigint(20) UNSIGNED NOT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `customer_rating_type` enum('automatic','manual') NOT NULL DEFAULT 'automatic',
  `customer_rating_value` tinyint(3) UNSIGNED DEFAULT NULL,
  `change_cliche_threshold` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `added_by_user` bigint(20) UNSIGNED DEFAULT NULL,
  `updated_by_user` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`id`, `status`, `company`, `client_name`, `location_id`, `address`, `contact_number`, `date_of_subscription`, `currency_id`, `amount`, `marketing_amount`, `subscription_type`, `payment_type`, `notified_at`, `suspension_days`, `is_credit_allowed`, `suspended_at`, `package_id`, `client_need_id`, `category_id`, `customer_rating_type`, `customer_rating_value`, `change_cliche_threshold`, `created_at`, `updated_at`, `added_by_user`, `updated_by_user`) VALUES
(1, 1, 'شركة سنان للصرافة والتحويلات', 'عمر العثماني', 3, 'سيئون', '774460666', '2025-06-15 21:00:00', 1, 150.00, 50.00, 'monthly', 'advance', NULL, NULL, 1, NULL, 2, 2, 1, 'manual', 8, 60, '2025-06-16 19:26:59', '2025-06-23 00:52:05', 1, 1),
(2, 1, 'رواد البركة للتجارة', NULL, 2, 'المكلا', NULL, '2025-06-15 21:00:00', 2, 15000.00, NULL, 'monthly', 'advance', NULL, 7, 0, NULL, 2, 1, 2, 'manual', 6, 60, '2025-06-16 19:52:41', '2025-06-24 13:50:24', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `client_needs`
--

CREATE TABLE `client_needs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `importance_level` enum('عالية جداً','عالية','متوسطة','منخفضة') DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `added_by_user` bigint(20) UNSIGNED DEFAULT NULL,
  `updated_by_user` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `client_needs`
--

INSERT INTO `client_needs` (`id`, `importance_level`, `name`, `created_at`, `updated_at`, `added_by_user`, `updated_by_user`) VALUES
(1, 'عالية', 'يشتي منتجاته', '2025-06-15 09:51:45', '2025-06-15 09:51:45', 1, 1),
(2, 'عالية جداً', 'جمعة', '2025-06-16 19:28:00', '2025-06-16 19:28:00', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `client_need_tags_group`
--

CREATE TABLE `client_need_tags_group` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `client_need_id` bigint(20) UNSIGNED NOT NULL,
  `tags_group_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `client_need_tags_group`
--

INSERT INTO `client_need_tags_group` (`id`, `client_need_id`, `tags_group_id`, `created_at`, `updated_at`) VALUES
(1, 1, 1, NULL, NULL),
(2, 2, 2, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `currencies`
--

CREATE TABLE `currencies` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `currency` varchar(255) NOT NULL,
  `currency_name` varchar(255) NOT NULL,
  `value` decimal(15,4) NOT NULL,
  `added_by_user` bigint(20) UNSIGNED DEFAULT NULL,
  `updated_by_user` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `currencies`
--

INSERT INTO `currencies` (`id`, `currency`, `currency_name`, `value`, `added_by_user`, `updated_by_user`, `created_at`, `updated_at`) VALUES
(1, 'SAR', 'ريال سعودي', 139.0000, 1, 1, '2025-06-16 19:22:31', '2025-06-16 19:23:51'),
(2, 'RY', 'ريال يمني', 1.0000, 1, 1, '2025-06-16 19:22:45', '2025-06-16 19:22:45'),
(3, 'USD', 'دولار أمريكي', 530.0000, 1, 1, '2025-06-16 19:23:03', '2025-06-16 19:23:03');

-- --------------------------------------------------------

--
-- Table structure for table `custody`
--

CREATE TABLE `custody` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `added_by_user` bigint(20) UNSIGNED DEFAULT NULL,
  `updated_by_user` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `custody`
--

INSERT INTO `custody` (`id`, `name`, `user_id`, `created_at`, `updated_at`, `added_by_user`, `updated_by_user`) VALUES
(2, 'فلاش الفرمته', 2, '2025-06-15 12:21:32', '2025-06-15 12:21:32', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `designers`
--

CREATE TABLE `designers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `min_capacity` int(11) DEFAULT NULL,
  `max_capacity` int(11) DEFAULT NULL,
  `rate` decimal(8,2) DEFAULT NULL,
  `shift_hours` int(11) DEFAULT NULL,
  `discipline_score` decimal(5,2) DEFAULT NULL,
  `amount_of_designs` int(11) DEFAULT NULL,
  `freepik_account` varchar(255) DEFAULT NULL,
  `pc_number` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `added_by_user` bigint(20) UNSIGNED DEFAULT NULL,
  `updated_by_user` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `designers`
--

INSERT INTO `designers` (`id`, `user_id`, `min_capacity`, `max_capacity`, `rate`, `shift_hours`, `discipline_score`, `amount_of_designs`, `freepik_account`, `pc_number`, `created_at`, `updated_at`, `added_by_user`, `updated_by_user`) VALUES
(1, 2, 80, 100, 5.00, 7, NULL, 0, NULL, '10', '2025-06-15 09:02:42', '2025-06-15 09:02:42', NULL, NULL),
(2, 1, 60, 100, 9.00, 7, NULL, 0, NULL, '2', '2025-06-15 12:20:21', '2025-06-15 12:20:21', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) UNSIGNED NOT NULL,
  `reserved_at` int(10) UNSIGNED DEFAULT NULL,
  `available_at` int(10) UNSIGNED NOT NULL,
  `created_at` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `job_batches`
--

CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `locations`
--

CREATE TABLE `locations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `added_by_user` bigint(20) UNSIGNED DEFAULT NULL,
  `updated_by_user` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `locations`
--

INSERT INTO `locations` (`id`, `name`, `created_at`, `updated_at`, `added_by_user`, `updated_by_user`) VALUES
(1, 'شمالي', '2025-06-15 09:55:45', '2025-06-15 09:55:45', 1, 1),
(2, 'جنوبي', '2025-06-15 09:55:51', '2025-06-15 09:55:51', 1, 1),
(3, 'يمني', '2025-06-15 09:56:00', '2025-06-15 09:56:00', 1, 1),
(4, 'سعودي', '2025-06-15 09:56:05', '2025-06-15 09:56:05', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '0001_01_01_000000_create_users_table', 1),
(2, '0001_01_01_000001_create_cache_table', 1),
(3, '0001_01_01_000002_create_jobs_table', 1),
(4, '2025_05_21_232151_create_permission_tables', 1),
(5, '2025_05_22_004658_create_categories_table', 1),
(6, '2025_05_22_004728_create_designers_table', 1),
(7, '2025_05_22_004758_create_category_designer_table', 1),
(8, '2025_05_22_020859_create_locations_table', 1),
(9, '2025_05_22_021912_create_social_media_table', 1),
(10, '2025_05_22_022945_create_currencies_table', 1),
(11, '2025_05_25_175121_create_custody_table', 1),
(12, '2025_05_25_211051_create_client_needs_table', 1),
(13, '2025_05_25_212736_create_tags_groups_table', 1),
(14, '2025_05_25_213920_create_tags_table', 1),
(15, '2025_06_15_121414_add_fields_to_client_needs_table', 2),
(16, '2025_06_15_121620_create_category_client_need_table', 2),
(17, '2025_06_15_121717_create_client_need_tags_group_table', 2),
(18, '2025_06_16_205110_create_packages_table', 3),
(19, '2025_06_16_212314_create_clients_table', 4),
(20, '2025_06_23_025512_add_status_to_clients_table', 5);

-- --------------------------------------------------------

--
-- Table structure for table `model_has_permissions`
--

CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `model_has_roles`
--

CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `packages`
--

CREATE TABLE `packages` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `package_type` varchar(255) NOT NULL,
  `design_limit` int(10) UNSIGNED NOT NULL DEFAULT 1,
  `package_original_price` decimal(10,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `added_by_user` bigint(20) UNSIGNED DEFAULT NULL,
  `updated_by_user` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `packages`
--

INSERT INTO `packages` (`id`, `package_type`, `design_limit`, `package_original_price`, `created_at`, `updated_at`, `added_by_user`, `updated_by_user`) VALUES
(1, 'فضية', 3, 15000.00, '2025-06-16 18:12:01', '2025-06-16 18:12:01', NULL, NULL),
(2, 'ذهبية', 4, 20000.00, '2025-06-16 18:12:17', '2025-06-16 18:12:17', NULL, NULL),
(3, 'ماسية', 7, 40000.00, '2025-06-16 18:13:02', '2025-06-16 18:13:02', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `guard_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `guard_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `role_has_permissions`
--

CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `role_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('CIpnLSuvuB29VLzXX73KpnZ8i4jQk8FYZhji3U8l', 1, '10.0.0.156', 'Mozilla/5.0 (Linux; Android 6.0.1; SM-S727VL) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Mobile Safari/537.36', 'YTo3OntzOjY6Il90b2tlbiI7czo0MDoiUmNnVmxCQkVmZUxvV3Jqa2V3eUNRckNSNXdudGdvMmU3OHI5ZTZMOCI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDg6Imh0dHA6Ly8xMC4wLjAuMTczOjgwMDAvYWRtaW4vc29jaWFsLW1lZGlhLzQvZWRpdCI7fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjE7czoxNzoicGFzc3dvcmRfaGFzaF93ZWIiO3M6NjA6IiQyeSQxMiRqb0JWaDg4dXN4V3dXaHJDZVFmQU9PZ1Jhb2dBd21JbkFNV3NIQUVJU1I1c2RJN1hVZGtteSI7czo4OiJmaWxhbWVudCI7YTowOnt9czo2OiJ0YWJsZXMiO2E6Mjp7czozMToiTGlzdFNvY2lhbE1lZGlhX3RvZ2dsZWRfY29sdW1ucyI7YTo1OntzOjQ6Im5hbWUiO2I6MTtzOjc6ImFkZGVkQnkiO2E6MTp7czo0OiJuYW1lIjtiOjA7fXM6OToidXBkYXRlZEJ5IjthOjE6e3M6NDoibmFtZSI7YjowO31zOjEwOiJjcmVhdGVkX2F0IjtiOjA7czoxMDoidXBkYXRlZF9hdCI7YjowO31zOjI0OiJMaXN0U29jaWFsTWVkaWFfcGVyX3BhZ2UiO3M6MjoiMTAiO319', 1750783988),
('kbHnPf95NGKRSJ47FaoG4O9ddZa6zwlns9PFLASx', 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36', 'YTo2OntzOjY6Il90b2tlbiI7czo0MDoiUEtXWlo1b0tjTEluRG5ZWWE5Wjkxcld2V3I2NFlkVVo5SVdXYTdSZyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzU6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9hZG1pbi9jbGllbnRzIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czozOiJ1cmwiO2E6MDp7fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjE7czoxNzoicGFzc3dvcmRfaGFzaF93ZWIiO3M6NjA6IiQyeSQxMiRqb0JWaDg4dXN4V3dXaHJDZVFmQU9PZ1Jhb2dBd21JbkFNV3NIQUVJU1I1c2RJN1hVZGtteSI7fQ==', 1750782897),
('NyvI4JV7Xod42G8ZIkWylo2dP5y0WppMyC7m2wfx', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiaHViaVZhSkUxR3ZWV1NWdXBFYXgyVVVYTlVVMzZUOGptRllybFprcSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjE6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1750782624),
('RLgoRSVs7WxXsq3OUvo6cwsNzWRANgpQZn3QOUhy', 1, '10.0.0.173', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36', 'YTo2OntzOjY6Il90b2tlbiI7czo0MDoidjVhMHJRUmo5WTB6MHpsR0FEYnZUSHNVMzZRRFFMQU1Ka093bnZ6RCI7czozOiJ1cmwiO2E6MDp7fXM6OToiX3ByZXZpb3VzIjthOjE6e3M6MzoidXJsIjtzOjM2OiJodHRwOi8vMTAuMC4wLjE3Mzo4MDAwL2FkbWluL2NsaWVudHMiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aToxO3M6MTc6InBhc3N3b3JkX2hhc2hfd2ViIjtzOjYwOiIkMnkkMTIkam9CVmg4OHVzeFd3V2hyQ2VRZkFPT2dSYW9nQXdtSW5BTVdzSEFFSVNSNXNkSTdYVWRrbXkiO30=', 1750784783);

-- --------------------------------------------------------

--
-- Table structure for table `social_media`
--

CREATE TABLE `social_media` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `added_by_user` bigint(20) UNSIGNED DEFAULT NULL,
  `updated_by_user` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `social_media`
--

INSERT INTO `social_media` (`id`, `name`, `created_at`, `updated_at`, `added_by_user`, `updated_by_user`) VALUES
(1, 'فيسبوك', '2025-06-15 12:23:08', '2025-06-15 12:23:08', 1, 1),
(2, 'انستقرام', '2025-06-15 12:23:13', '2025-06-15 12:23:13', 1, 1),
(3, 'قناة واتساب', '2025-06-15 12:23:22', '2025-06-15 12:23:22', 1, 1),
(4, 'تيكتوك', '2025-06-24 13:52:58', '2025-06-24 13:52:58', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tags`
--

CREATE TABLE `tags` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `importance` enum('veryhigh','high','medium','low') NOT NULL DEFAULT 'medium',
  `category_id` bigint(20) UNSIGNED DEFAULT NULL,
  `location_id` bigint(20) UNSIGNED DEFAULT NULL,
  `tag_group_id` bigint(20) UNSIGNED NOT NULL,
  `is_repetition` tinyint(1) NOT NULL DEFAULT 0,
  `repetition` enum('weekly','monthly','yearly') DEFAULT NULL,
  `weekly_times` int(11) DEFAULT NULL,
  `monthly_times` int(11) DEFAULT NULL,
  `yearly_times` int(11) DEFAULT NULL,
  `is_there_date_for_sending` tinyint(1) NOT NULL DEFAULT 0,
  `date_for_sending_yearly` date DEFAULT NULL,
  `weekly_day` enum('Saturday','Sunday','Monday','Tuesday','Wednesday','Thursday','Friday') DEFAULT NULL,
  `weekly_time` time DEFAULT NULL,
  `weekly_time_sm` time DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `added_by_user` bigint(20) UNSIGNED DEFAULT NULL,
  `updated_by_user` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tags`
--

INSERT INTO `tags` (`id`, `name`, `importance`, `category_id`, `location_id`, `tag_group_id`, `is_repetition`, `repetition`, `weekly_times`, `monthly_times`, `yearly_times`, `is_there_date_for_sending`, `date_for_sending_yearly`, `weekly_day`, `weekly_time`, `weekly_time_sm`, `created_at`, `updated_at`, `added_by_user`, `updated_by_user`) VALUES
(1, 'جمعة للجنوبيين', 'veryhigh', 1, 2, 2, 1, 'weekly', 4, NULL, NULL, 1, NULL, 'Thursday', '14:00:00', '17:00:00', '2025-06-15 12:28:03', '2025-06-15 12:28:03', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tags_groups`
--

CREATE TABLE `tags_groups` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `added_by_user` bigint(20) UNSIGNED DEFAULT NULL,
  `updated_by_user` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tags_groups`
--

INSERT INTO `tags_groups` (`id`, `name`, `created_at`, `updated_at`, `added_by_user`, `updated_by_user`) VALUES
(1, 'منتجات', '2025-06-15 09:47:31', '2025-06-15 09:47:31', 1, 1),
(2, 'جمعة', '2025-06-15 09:47:35', '2025-06-15 09:47:35', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `work_phone_number` varchar(255) DEFAULT NULL,
  `personal_phone_number` varchar(255) DEFAULT NULL,
  `profile_image` varchar(255) DEFAULT NULL,
  `hire_date` date DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `email`, `email_verified_at`, `password`, `work_phone_number`, `personal_phone_number`, `profile_image`, `hire_date`, `status`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'ناصر غراب', 'admin', 'admin@admin.com', NULL, '$2y$12$joBVh88usxWwWhrCeQfAOOgRaogAwmInAMWsHAEISR5sdI7XUdkmy', '782233333', '773269216', 'profile_images/file (10).jpg', '2025-05-28', 1, 'F9uiicCONdrh55hqoGnU4Ip5tTIZUhrbX4STfItb4JQ4nD9GS0tgZozOCPzx', '2025-05-29 02:07:50', '2025-06-15 11:38:03'),
(2, 'عبدالله الفقيه', 'abdo2', 'abdo@admin.com', NULL, '$2y$12$ElG2uDPnL5ZuPnpmTXxd7uayPSiIyXae9Q7pYXbj5JvP84dfKxfR.', '781388509', '774453189', 'profile_images/unnamed.jpg', '2023-12-29', 0, NULL, '2025-06-15 08:42:15', '2025-06-15 12:10:57');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cache`
--
ALTER TABLE `cache`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `cache_locks`
--
ALTER TABLE `cache_locks`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `categories_added_by_user_foreign` (`added_by_user`),
  ADD KEY `categories_updated_by_user_foreign` (`updated_by_user`);

--
-- Indexes for table `category_client_need`
--
ALTER TABLE `category_client_need`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category_client_need_client_need_id_foreign` (`client_need_id`),
  ADD KEY `category_client_need_category_id_foreign` (`category_id`);

--
-- Indexes for table `category_designer`
--
ALTER TABLE `category_designer`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category_designer_designer_id_foreign` (`designer_id`),
  ADD KEY `category_designer_category_id_foreign` (`category_id`);

--
-- Indexes for table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`id`),
  ADD KEY `clients_location_id_foreign` (`location_id`),
  ADD KEY `clients_currency_id_foreign` (`currency_id`),
  ADD KEY `clients_package_id_foreign` (`package_id`),
  ADD KEY `clients_client_need_id_foreign` (`client_need_id`),
  ADD KEY `clients_category_id_foreign` (`category_id`),
  ADD KEY `clients_added_by_user_foreign` (`added_by_user`),
  ADD KEY `clients_updated_by_user_foreign` (`updated_by_user`);

--
-- Indexes for table `client_needs`
--
ALTER TABLE `client_needs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `client_needs_added_by_user_foreign` (`added_by_user`),
  ADD KEY `client_needs_updated_by_user_foreign` (`updated_by_user`);

--
-- Indexes for table `client_need_tags_group`
--
ALTER TABLE `client_need_tags_group`
  ADD PRIMARY KEY (`id`),
  ADD KEY `client_need_tags_group_client_need_id_foreign` (`client_need_id`),
  ADD KEY `client_need_tags_group_tags_group_id_foreign` (`tags_group_id`);

--
-- Indexes for table `currencies`
--
ALTER TABLE `currencies`
  ADD PRIMARY KEY (`id`),
  ADD KEY `currencies_added_by_user_foreign` (`added_by_user`),
  ADD KEY `currencies_updated_by_user_foreign` (`updated_by_user`);

--
-- Indexes for table `custody`
--
ALTER TABLE `custody`
  ADD PRIMARY KEY (`id`),
  ADD KEY `custody_user_id_foreign` (`user_id`),
  ADD KEY `custody_added_by_user_foreign` (`added_by_user`),
  ADD KEY `custody_updated_by_user_foreign` (`updated_by_user`);

--
-- Indexes for table `designers`
--
ALTER TABLE `designers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `designers_user_id_foreign` (`user_id`),
  ADD KEY `designers_added_by_user_foreign` (`added_by_user`),
  ADD KEY `designers_updated_by_user_foreign` (`updated_by_user`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `jobs_queue_index` (`queue`);

--
-- Indexes for table `job_batches`
--
ALTER TABLE `job_batches`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `locations`
--
ALTER TABLE `locations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `locations_added_by_user_foreign` (`added_by_user`),
  ADD KEY `locations_updated_by_user_foreign` (`updated_by_user`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  ADD KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indexes for table `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  ADD KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indexes for table `packages`
--
ALTER TABLE `packages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `packages_added_by_user_foreign` (`added_by_user`),
  ADD KEY `packages_updated_by_user_foreign` (`updated_by_user`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`);

--
-- Indexes for table `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`role_id`),
  ADD KEY `role_has_permissions_role_id_foreign` (`role_id`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sessions_user_id_index` (`user_id`),
  ADD KEY `sessions_last_activity_index` (`last_activity`);

--
-- Indexes for table `social_media`
--
ALTER TABLE `social_media`
  ADD PRIMARY KEY (`id`),
  ADD KEY `social_media_added_by_user_foreign` (`added_by_user`),
  ADD KEY `social_media_updated_by_user_foreign` (`updated_by_user`);

--
-- Indexes for table `tags`
--
ALTER TABLE `tags`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tags_category_id_foreign` (`category_id`),
  ADD KEY `tags_location_id_foreign` (`location_id`),
  ADD KEY `tags_tag_group_id_foreign` (`tag_group_id`),
  ADD KEY `tags_added_by_user_foreign` (`added_by_user`),
  ADD KEY `tags_updated_by_user_foreign` (`updated_by_user`);

--
-- Indexes for table `tags_groups`
--
ALTER TABLE `tags_groups`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tags_groups_added_by_user_foreign` (`added_by_user`),
  ADD KEY `tags_groups_updated_by_user_foreign` (`updated_by_user`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_username_unique` (`username`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `category_client_need`
--
ALTER TABLE `category_client_need`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `category_designer`
--
ALTER TABLE `category_designer`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `clients`
--
ALTER TABLE `clients`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `client_needs`
--
ALTER TABLE `client_needs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `client_need_tags_group`
--
ALTER TABLE `client_need_tags_group`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `currencies`
--
ALTER TABLE `currencies`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `custody`
--
ALTER TABLE `custody`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `designers`
--
ALTER TABLE `designers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `locations`
--
ALTER TABLE `locations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `packages`
--
ALTER TABLE `packages`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `social_media`
--
ALTER TABLE `social_media`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tags`
--
ALTER TABLE `tags`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tags_groups`
--
ALTER TABLE `tags_groups`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `categories`
--
ALTER TABLE `categories`
  ADD CONSTRAINT `categories_added_by_user_foreign` FOREIGN KEY (`added_by_user`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `categories_updated_by_user_foreign` FOREIGN KEY (`updated_by_user`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `category_client_need`
--
ALTER TABLE `category_client_need`
  ADD CONSTRAINT `category_client_need_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `category_client_need_client_need_id_foreign` FOREIGN KEY (`client_need_id`) REFERENCES `client_needs` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `category_designer`
--
ALTER TABLE `category_designer`
  ADD CONSTRAINT `category_designer_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `category_designer_designer_id_foreign` FOREIGN KEY (`designer_id`) REFERENCES `designers` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `clients`
--
ALTER TABLE `clients`
  ADD CONSTRAINT `clients_added_by_user_foreign` FOREIGN KEY (`added_by_user`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `clients_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`),
  ADD CONSTRAINT `clients_client_need_id_foreign` FOREIGN KEY (`client_need_id`) REFERENCES `client_needs` (`id`),
  ADD CONSTRAINT `clients_currency_id_foreign` FOREIGN KEY (`currency_id`) REFERENCES `currencies` (`id`),
  ADD CONSTRAINT `clients_location_id_foreign` FOREIGN KEY (`location_id`) REFERENCES `locations` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `clients_package_id_foreign` FOREIGN KEY (`package_id`) REFERENCES `packages` (`id`),
  ADD CONSTRAINT `clients_updated_by_user_foreign` FOREIGN KEY (`updated_by_user`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `client_needs`
--
ALTER TABLE `client_needs`
  ADD CONSTRAINT `client_needs_added_by_user_foreign` FOREIGN KEY (`added_by_user`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `client_needs_updated_by_user_foreign` FOREIGN KEY (`updated_by_user`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `client_need_tags_group`
--
ALTER TABLE `client_need_tags_group`
  ADD CONSTRAINT `client_need_tags_group_client_need_id_foreign` FOREIGN KEY (`client_need_id`) REFERENCES `client_needs` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `client_need_tags_group_tags_group_id_foreign` FOREIGN KEY (`tags_group_id`) REFERENCES `tags_groups` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `currencies`
--
ALTER TABLE `currencies`
  ADD CONSTRAINT `currencies_added_by_user_foreign` FOREIGN KEY (`added_by_user`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `currencies_updated_by_user_foreign` FOREIGN KEY (`updated_by_user`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `custody`
--
ALTER TABLE `custody`
  ADD CONSTRAINT `custody_added_by_user_foreign` FOREIGN KEY (`added_by_user`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `custody_updated_by_user_foreign` FOREIGN KEY (`updated_by_user`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `custody_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `designers`
--
ALTER TABLE `designers`
  ADD CONSTRAINT `designers_added_by_user_foreign` FOREIGN KEY (`added_by_user`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `designers_updated_by_user_foreign` FOREIGN KEY (`updated_by_user`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `designers_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `locations`
--
ALTER TABLE `locations`
  ADD CONSTRAINT `locations_added_by_user_foreign` FOREIGN KEY (`added_by_user`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `locations_updated_by_user_foreign` FOREIGN KEY (`updated_by_user`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `packages`
--
ALTER TABLE `packages`
  ADD CONSTRAINT `packages_added_by_user_foreign` FOREIGN KEY (`added_by_user`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `packages_updated_by_user_foreign` FOREIGN KEY (`updated_by_user`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `social_media`
--
ALTER TABLE `social_media`
  ADD CONSTRAINT `social_media_added_by_user_foreign` FOREIGN KEY (`added_by_user`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `social_media_updated_by_user_foreign` FOREIGN KEY (`updated_by_user`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `tags`
--
ALTER TABLE `tags`
  ADD CONSTRAINT `tags_added_by_user_foreign` FOREIGN KEY (`added_by_user`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `tags_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `tags_location_id_foreign` FOREIGN KEY (`location_id`) REFERENCES `locations` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `tags_tag_group_id_foreign` FOREIGN KEY (`tag_group_id`) REFERENCES `tags_groups` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `tags_updated_by_user_foreign` FOREIGN KEY (`updated_by_user`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `tags_groups`
--
ALTER TABLE `tags_groups`
  ADD CONSTRAINT `tags_groups_added_by_user_foreign` FOREIGN KEY (`added_by_user`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `tags_groups_updated_by_user_foreign` FOREIGN KEY (`updated_by_user`) REFERENCES `users` (`id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
