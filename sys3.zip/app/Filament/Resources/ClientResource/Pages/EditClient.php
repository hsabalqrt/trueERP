<?php

namespace App\Filament\Resources\ClientResource\Pages;

use App\Filament\Resources\ClientResource;
use Filament\Actions;
use Filament\Resources\Pages\EditRecord;
use Illuminate\Support\Facades\Auth;

use Filament\Actions\Action;
use Filament\Notifications\Notification;

class EditClient extends EditRecord
{
    protected static string $resource = ClientResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\DeleteAction::make(),
            Action::make('toggle_status')
                ->label($this->record->status ? '🔴 إيقاف العميل' : '🟢 تفعيل العميل')
                ->color($this->record->status ? 'danger' : 'success')
                ->action(function () {
                    $this->record->status = ! $this->record->status;
                    $this->record->save();

                    Notification::make()
                        ->title($this->record->status ? 'تم تفعيل العميل' : 'تم إيقاف العميل')
                        ->success()
                        ->send();
                })
                ->requiresConfirmation()
                ->icon($this->record->status ? 'heroicon-o-x-circle' : 'heroicon-o-check-circle'),
        ];
    }

    public function getSubheading(): ?string
    {
        return $this->record->status ? '🟢 العميل شغال' : '🔴 العميل موقّف';
    }


    protected function mutateFormDataBeforeSave(array $data): array
    {
        $data['updated_by_user'] = Auth::id();
        if ($data['is_credit_allowed']) {
            $data['suspension_days'] = null;
        }
        if (($data['customer_rating_type'] ?? null) === 'automatic') {
            // احسب التقييم تلقائيًا
            // if (!empty($data['amount']) && !empty($data['packages']['package_original_price'])) {
            //     $data['customer_rating_value'] = round(
            //         ($data['amount'] / $data['packages']['package_original_price']) * 10
            //     );
            // }
            $amount = $data['amount'];

            $packageId = $data['package_id']; // افترض أن هناك حقل اختيار للحزمة مرتبط بجدول packages
            if ($amount && $packageId) {
                $package = \App\Models\Package::find($packageId);
                if ($package && $package->package_original_price != 0) {
                    $data['customer_rating_value'] = round(($amount / $package->package_original_price) * 10);
                    // $set('customer_rating_value', $rating);
                }
            }
        }
        return $data;
    }
}
