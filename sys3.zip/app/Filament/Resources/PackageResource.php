<?php

namespace App\Filament\Resources;

use App\Filament\Resources\PackageResource\Pages;
use App\Filament\Resources\PackageResource\RelationManagers;
use App\Models\Package;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Forms\Components\TextInput;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Filament\Tables\Columns\TextColumn;
use Filament\Forms\Components\Section;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletingScope;

class PackageResource extends Resource
{
    protected static ?string $model = Package::class;

    protected static ?string $navigationIcon = 'heroicon-o-rectangle-stack';
    protected static ?string $navigationGroup = 'CRM';
    protected static ?string $navigationLabel = 'الباقات';
    protected static ?string $pluralLabel = 'الباقات';
    protected static ?string $label = 'باقة';
    protected static ?string $slug = 'packages';
    protected static ?string $recordTitleAttribute = 'package_type';
    protected static ?string $modelLabel = 'باقة';
    protected static ?string $pluralModelLabel = 'الباقات';
    protected static ?string $modelLabelPlural = 'الباقات';
    protected static ?string $modelLabelSingular = 'باقة';
    protected static ?string $modelLabelSingularPlural = 'الباقة';
    protected static ?string $navigationBadge = 'جديد';
    protected static ?string $navigationBadgeColor = 'success';
    protected static ?string $navigationSearch = 'true';
    protected static ?string $navigationSearchPlaceholder = 'ابحث عن باقة...';

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Section::make('بيانات الباقة')
                ->schema([
                    TextInput::make('package_type')
                    ->label('نوع الباقة')
                    ->required()
                    ->maxLength(255),

                    TextInput::make('design_limit')
                        ->label('عدد التصاميم')
                        ->numeric()
                        ->default(1)
                        ->minValue(1)
                        ->required(),

                    TextInput::make('package_original_price')
                        ->label('السعر الأصلي للباقة')
                        ->numeric()
                        ->step(0.01)
                        ->required(),
                ]),
                
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('package_type')->label('نوع الباقة'),
                TextColumn::make('design_limit')->label('عدد التصاميم'),
                TextColumn::make('package_original_price')
                    ->label('السعر'),
                TextColumn::make('created_at')
                    ->label('تاريخ الإنشاء')
                    ->dateTime('Y-m-d'),
            ])
            ->filters([
                //
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListPackages::route('/'),
            'create' => Pages\CreatePackage::route('/create'),
            'edit' => Pages\EditPackage::route('/{record}/edit'),
        ];
    }
}
