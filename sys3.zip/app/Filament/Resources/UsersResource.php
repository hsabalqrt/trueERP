<?php

namespace App\Filament\Resources;

use App\Filament\Resources\UsersResource\Pages;
use App\Filament\Resources\UsersResource\RelationManagers;
use App\Models\User;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletingScope;
use Filament\Forms\Components\Section;
use Filament\Infolists\Infolist;
use Filament\Infolists\Components\TextEntry;
// use Filament\Infolists\Infolist;
// use Filament\Infolists\Components\TextEntry;






class UsersResource extends Resource
{
    protected static ?string $model = User::class;

    protected static ?string $navigationIcon = 'heroicon-o-users';
    protected static ?string $navigationLabel = 'المستخدمون';
    protected static ?string $pluralLabel = 'المستخدمون';
    protected static ?string $label = 'مستخدم';
    protected static ?string $slug = 'users';
    protected static ?string $navigationGroup = 'المستخدمون';
    protected static ?int $navigationSort = 0;
    protected static ?string $recordTitleAttribute = 'name';
    protected static ?string $modelLabel = 'مستخدم';
    protected static ?string $pluralModelLabel = 'المستخدمون';
    protected static ?string $modelLabelPlural = 'المستخدمون';
    protected static ?string $modelLabelSingular = 'مستخدم';
    protected static ?string $modelLabelSingularPlural = 'المستخدم';
    protected static ?string $navigationBadge = 'جديد';
    protected static ?string $navigationBadgeColor = 'success';
    protected static ?string $navigationSearch = 'true';
    protected static ?string $navigationSearchPlaceholder = 'ابحث عن مستخدم...';

    public static function getNavigationBadge(): ?string
    {
        return static::getModel()::count();
    }

    public static function getNavigationBadgeColor(): ?string
    {
        return static::getModel()::count() < 10 ? 'warning' : 'primary';
    }

    protected static ?string $navigationBadgeTooltip = 'عدد المستخدمون';

    public static function infolist(Infolist $infolist): Infolist
    {
        return $infolist->schema([
            TextEntry::make('name')->label('الاسم'),
            TextEntry::make('email')->label('البريد الإلكتروني'),
        ]);
    }

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Section::make('معلومات المستخدم')
                    ->schema([
                        Forms\Components\TextInput::make('name')
                            ->label('الاسم الكامل')
                            ->required()
                            ->maxLength(255),
                        Forms\Components\TextInput::make('username')
                            ->label('اسم المستخدم')
                            ->required()
                            ->unique(table: 'users', column: 'username', ignorable: fn($record) => $record)
                            ->maxLength(255),
                        Forms\Components\TextInput::make('email')
                            ->label('البريد الإلكتروني')
                            ->required()
                            ->email()
                            ->unique(table: 'users', column: 'email', ignorable: fn($record) => $record)
                            ->maxLength(255),
                        Forms\Components\TextInput::make('password')
                            ->label('كلمة المرور')
                            ->password()
                            ->required(fn(string $context) => $context === 'create') // Only required on create
                            ->dehydrated(fn($state) => filled($state)) // don't save confirmation field
                            ->dehydrateStateUsing(fn($state) => bcrypt($state))
                            ->maxLength(255),
                    ])->columns(2),
                Section::make('معلومات الاتصال')
                    ->schema([
                        Forms\Components\TextInput::make('work_phone_number')
                            ->label('رقم الهاتف للعمل')
                            ->tel()
                            ->maxLength(255),
                        Forms\Components\TextInput::make('personal_phone_number')
                            ->label('رقم الهاتف الشخصي')
                            ->tel()
                            ->maxLength(255),
                    ])->columns(2),
                Section::make('الصورة الشخصية')
                    ->description('يمكنك تحميل صورة شخصية للمستخدم')
                    ->schema([
                        Forms\Components\FileUpload::make('profile_image')
                            ->label('')
                            ->image()
                            ->disk('public')
                            ->directory('profile_images')
                            ->preserveFilenames(),
                    ]),
                Section::make('تاريخ التوظيف والحالة')
                    ->schema([
                        Forms\Components\DatePicker::make('hire_date')
                            ->label('تاريخ التوظيف')
                            ->required(),
                        Forms\Components\Toggle::make('status')
                            ->label('الحالة')
                            ->onColor('success')
                            ->offColor('danger')
                            // Disable the toggle for the current authenticated user
                            ->disabled(fn($record) => $record?->id === auth()->id())
                            ->default(true)
                    ])->columns(1),
            ])->columns(2);
    }



    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\ImageColumn::make('profile_image')
                    ->circular()
                    ->label(''),
                Tables\Columns\TextColumn::make('name')->label('الاسم')->sortable()->searchable()->toggleable(),
                Tables\Columns\TextColumn::make('username')->sortable()->searchable()->toggleable()->label('اسم المستخدم'),
                Tables\Columns\TextColumn::make('email')->sortable()->searchable()->toggleable()->label('البريد الإلكتروني'),
                Tables\Columns\TextColumn::make('work_phone_number')->sortable()->searchable()->toggleable()->label('رقم الهاتف العمل'),
                Tables\Columns\TextColumn::make('personal_phone_number')->sortable()->searchable()->toggleable()->label('رقم الهاتف الشخصي'),
                // Tables\Columns\TextColumn::make('profile_image')->sortable()->searchable(),
                Tables\Columns\TextColumn::make('hire_date')->sortable()->searchable()->toggleable()->label('تاريخ التوظيف'),
                Tables\Columns\BooleanColumn::make('status')->sortable()->searchable()->toggleable()->label('الحالة'),
            ])
            ->filters([
                Tables\Filters\Filter::make('active')
                    ->query(fn(Builder $query) => $query->where('status', true))
                    ->label('المستخدمون النشطون'),
                Tables\Filters\Filter::make('inactive')
                    ->query(fn(Builder $query) => $query->where('status', false))
                    ->label('المستخدمون غير النشطين'),
            ])
            ->actions([
                // Tables\Actions\ViewAction::make()->label('عرض')->icon('heroicon-o-eye')->color('primary'),
                Tables\Actions\EditAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListUsers::route('/'),
            'create' => Pages\CreateUsers::route('/create'),
            'edit' => Pages\EditUsers::route('/{record}/edit'),
            'view' => Pages\ViewUsers::route('/{record}'),
        ];
    }
}
