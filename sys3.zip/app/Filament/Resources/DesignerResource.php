<?php

namespace App\Filament\Resources;

use App\Filament\Resources\DesignerResource\Pages;
use App\Filament\Resources\DesignerResource\RelationManagers;
use App\Models\Designer;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Filament\Forms\Components\Section;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletingScope;


class DesignerResource extends Resource
{
    protected static ?string $model = Designer::class;

    protected static ?string $navigationIcon = 'heroicon-o-rectangle-stack';

    protected static ?string $navigationGroup = 'المستخدمون';
    protected static ?int $navigationSort = 1;
    protected static ?string $navigationLabel = 'المصممين';
    protected static ?string $recordTitleAttribute = 'user.name';
    protected static ?string $slug = 'designers';
    protected static ?string $modelLabel = 'مصمم';
    protected static ?string $pluralModelLabel = 'مصممين';
    protected static ?string $modelLabelPlural = 'المصممين';
    protected static ?string $pluralModelLabelPlural = 'المصممين';
    protected static ?string $navigationBadge = 'جديد';
    protected static ?string $navigationBadgeColor = 'success';
    protected static ?string $navigationSearch = 'true';
    protected static ?string $navigationSearchPlaceholder = 'ابحث عن مصمم...';
    protected static ?string $searchableAttribute = 'user.name';
    protected static ?string $searchableAttributePlural = 'user.name';

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Section::make('البيانات الأساسية')->schema([
                    Select::make('user_id')
                        ->relationship('user', 'name')
                        ->searchable()
                        ->preload()
                        ->label('المستخدم')
                        ->required(),

                    Select::make('categories')
                        ->multiple()
                        ->relationship('categories', 'name')
                        ->preload()
                        ->label('التصنيفات')
                        ->required(),
                ])->columns(2),

                Section::make('تفاصيل العمل')->schema([
                    TextInput::make('min_capacity')->numeric()->label('الحد الأدنى لعدد التصاميم'),
                    TextInput::make('max_capacity')->numeric()->label('الحد الأعلى لعدد التصاميم'),
                    TextInput::make('rate')->numeric()->label('التقييم'),
                    TextInput::make('shift_hours')->numeric()->label('ساعات الدوام'),
                    TextInput::make('discipline_score')->numeric()->label('الانضباط'),
                    TextInput::make('amount_of_designs')->numeric()->label('عدد التصاميم'),
                    TextInput::make('freepik_account')->label('حساب فري بيك'),
                    TextInput::make('pc_number')->label('رقم الجهاز'),
                ])->columns(2),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('user.name')->label('المستخدم')->searchable(),

                Tables\Columns\TextColumn::make('min_capacity')->label('الحد الأدنى للسعة'),
                Tables\Columns\TextColumn::make('max_capacity')->label('الحد الأقصى للسعة'),
                Tables\Columns\TextColumn::make('rate')->label('التقييم'),
                Tables\Columns\TextColumn::make('shift_hours')->label('عدد ساعات الدوام'),
                Tables\Columns\TextColumn::make('discipline_score')->label('تقييم الانضباط'),
                Tables\Columns\TextColumn::make('amount_of_designs')->label('عدد التصاميم'),

                Tables\Columns\TextColumn::make('freepik_account')->label('حساب فريبيك')->wrap(),
                Tables\Columns\TextColumn::make('pc_number')->label('رقم الجهاز'),

                Tables\Columns\TextColumn::make('categories.name')
                    ->label('التصنيفات')
                    ->badge()
                    ->separator(', ')
                    ->limit(30),
            ])
            ->filters([
                //
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListDesigners::route('/'),
            'create' => Pages\CreateDesigner::route('/create'),
            'edit' => Pages\EditDesigner::route('/{record}/edit'),
        ];
    }
}
