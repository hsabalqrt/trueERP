<?php

namespace App\Filament\Resources;

use App\Filament\Resources\TagGroupResource\Pages;
use App\Filament\Resources\TagGroupResource\RelationManagers;
use App\Models\TagGroup;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Filament\Tables\Columns\TextColumn;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletingScope;

class TagGroupResource extends Resource
{
    protected static ?string $model = TagGroup::class;

    protected static ?string $navigationIcon = 'heroicon-o-tag';
    protected static ?string $navigationLabel = 'مجموعات الوسوم';
    protected static ?string $pluralLabel = 'مجموعات الوسوم';
    protected static ?string $label = 'مجموعة وسم';
    protected static ?string $slug = 'tag-groups';
    protected static ?string $navigationGroup = 'المحتوى';

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Forms\Components\TextInput::make('name')
                    ->label('اسم المجموعة للوسوم')
                    ->required()
                    ->maxLength(100),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('name')->label('اسم المجموعة')->searchable(),
                TextColumn::make('addedByUser.name')->label('أُضيف بواسطة')->toggleable(),
                TextColumn::make('updatedByUser.name')->label('آخر تعديل بواسطة')->toggleable(),
                TextColumn::make('created_at')->label('تاريخ الإضافة')->toggleable(),
                TextColumn::make('updated_at')->label('آخر تعديل')->toggleable(),
            ])
            ->filters([
                //
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListTagGroups::route('/'),
            'create' => Pages\CreateTagGroup::route('/create'),
            'edit' => Pages\EditTagGroup::route('/{record}/edit'),
        ];
    }
}
