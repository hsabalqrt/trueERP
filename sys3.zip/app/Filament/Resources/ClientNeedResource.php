<?php

namespace App\Filament\Resources;

use App\Filament\Resources\ClientNeedResource\Pages;
use App\Filament\Resources\ClientNeedResource\RelationManagers;
use App\Models\ClientNeed;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletingScope;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Section;
use Filament\Forms\Components\Radio;

class ClientNeedResource extends Resource
{
    protected static ?string $model = ClientNeed::class;
    protected static ?string $navigationIcon = 'heroicon-o-rectangle-stack';
    protected static ?string $navigationGroup = 'المحتوى';
    protected static ?int $navigationSort = 3;
    protected static ?string $navigationLabel = 'احتياجات العملاء';
    protected static ?string $recordTitleAttribute = 'name';
    protected static ?string $slug = 'client-needs';
    protected static ?string $modelLabel = 'احتياج عميل';
    protected static ?string $pluralModelLabel = 'احتياجات العملاء';
    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Section::make('البيانات الأساسية')
                    ->schema([
                        Forms\Components\TextInput::make('name')
                            ->label('اسم الاحتياج')
                            ->required()
                            ->maxLength(255),
                    ]),
                Section::make('بيانات احتياج العميل')
                    ->schema([
                        Radio::make('importance_level')
                            ->label('درجة الأهمية')
                            ->options([
                                'عالية جداً' => 'عالية جداً',
                                'عالية' => 'عالية',
                                'متوسطة' => 'متوسطة',
                                'منخفضة' => 'منخفضة',
                            ])->columns(4)
                            ->required(),

                        Select::make('tagsGroups')
                            ->label('مجموعات التاقات')
                            ->relationship('tagsGroups', 'name')
                            ->multiple()
                            ->preload()
                            ->columns(2),

                        Select::make('categories')
                            ->label('التصنيفات')
                            ->relationship('categories', 'name')
                            ->multiple()
                            ->preload()
                            ->columns(2),
                            ]),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('name')
                    ->label('اسم الاحتياج')
                    ->sortable()
                    ->searchable(),
                Tables\Columns\TextColumn::make('importance_level')
                    ->label('درجة الأهمية')
                    ->sortable()
                    ->searchable(),

                Tables\Columns\TextColumn::make('tagsGroups.name')
                    ->label('مجموعات التاقات')
                    ->badge()
                    ->separator(', '),

                Tables\Columns\TextColumn::make('categories.name')
                    ->label('التصنيفات')
                    ->badge()
                    ->separator(', '),
                Tables\Columns\TextColumn::make('addedByUser.name')
                    ->label('أضيف بواسطة')
                    ->sortable()
                    ->searchable()
                    ->toggleable(),
                    Tables\Columns\TextColumn::make('updatedByUser.name')
                        ->label('عدّل بواسطة')
                        ->sortable()
                        ->searchable(),
                Tables\Columns\TextColumn::make('created_at')
                    ->label('تاريخ الإضافة')
                    ->dateTime()
                    ->sortable()
                    ->searchable()
                    ->toggleable(),
                Tables\Columns\TextColumn::make('updated_at')
                    ->label('تاريخ التحديث')
                    ->dateTime()
                    ->sortable()
                    ->searchable(),
            ])
            ->filters([
                //
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListClientNeeds::route('/'),
            'create' => Pages\CreateClientNeed::route('/create'),
            'edit' => Pages\EditClientNeed::route('/{record}/edit'),
        ];
    }
}
