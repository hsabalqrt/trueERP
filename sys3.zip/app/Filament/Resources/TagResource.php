<?php

namespace App\Filament\Resources;

use App\Filament\Resources\TagResource\Pages;
use App\Filament\Resources\TagResource\RelationManagers;
use App\Models\Tag;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Toggle;
use Filament\Forms\Components\DatePicker;
use Filament\Forms\Components\TimePicker;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Filament\Tables\Columns\TextColumn;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletingScope;
use Filament\Forms\Components\Section;
use Filament\Forms\Get;

class TagResource extends Resource
{
    protected static ?string $model = Tag::class;

    protected static ?string $navigationIcon = 'heroicon-o-tag';
    protected static ?string $navigationGroup = 'المحتوى';
    protected static ?int $navigationSort = 4;
    protected static ?string $navigationLabel = 'الوسوم';
    protected static ?string $recordTitleAttribute = 'name';
    protected static ?string $slug = 'tags';
    protected static ?string $modelLabel = 'وسم';
    protected static ?string $pluralModelLabel = 'وسوم';
    protected static ?string $modelLabelPlural = 'الوسوم';
    protected static ?string $modelLabelSingular = 'وسم';
    protected static ?string $modelLabelSingularPlural = 'وسم';
    protected static ?string $navigationBadge = 'جديد';
    protected static ?string $navigationBadgeColor = 'success';
    protected static ?string $navigationSearch = 'true';
    protected static ?string $navigationSearchPlaceholder = 'ابحث عن وسم...';

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Section::make('البيانات الأساسية')
                    ->schema([
                        Forms\Components\TextInput::make('name')
                            ->label('اسم الوسم')
                            ->required()
                            ->maxLength(100),
                    ]),
                Section::make('بيانات الوسم')
                    ->schema([
                        Select::make('importance')
                            ->label('درجة الأهمية')
                            ->options([
                                'veryhigh' => 'Very High',
                                'high' => 'High',
                                'medium' => 'Medium',
                                'low' => 'Low',
                            ])
                            ->default('medium'),
        
                        Select::make('category_id')
                            ->relationship('category', 'name')
                            ->searchable()
                            ->preload()
                            ->label('التصنيفات'),
        
                        Select::make('location_id')
                            ->relationship('location', 'name')
                            ->searchable()
                            ->preload()
                            ->label('المواقع'),
        
                        Select::make('tag_group_id')
                            ->label('مجموعات الوسوم')
                            ->relationship('tagGroup', 'name')
                            ->preload()
                            ->required(),
                    ])->columns(2),

                Section::make('بيانات التكرار')
                    ->schema([
                        Toggle::make('is_repetition')
                        ->label('متكرر؟')
                        ->live(),
        
                        Select::make('repetition')
                            ->label('نوع التكرار')
                            ->options([
                                'weekly' => 'Weekly',
                                // 'monthly' => 'Monthly',
                                'yearly' => 'Yearly',
                            ])
                            ->nullable()
                            ->live()
                            ->disabled(fn (Get $get): bool => ! $get('is_repetition')),
        
                        TextInput::make('weekly_times')->numeric()
                        ->nullable()
                        ->label('عدد مرات التكرار الأسبوعي')
                        ->live()
                        ->disabled(fn (Get $get): bool => ! $get('is_repetition')),
                        // TextInput::make('monthly_times')->numeric()->nullable(),
                        TextInput::make('yearly_times')
                        ->numeric()
                        ->nullable()
                        ->label('عدد مرات التكرار السنوي')
                        ->live()
                        ->disabled(fn (Get $get): bool => ! $get('is_repetition') || $get('repetition') !== 'yearly'),
                        // ->disabled(fn (Get $get): bool => ! $get('is_repetition')),
                    ])->columns(2),
                Section::make('بيانات الإرسال')
                    ->description('يمكنك تحديد تاريخ الإرسال أو اليوم والوقت الأسبوعي')
                    ->schema([
                        Toggle::make('is_there_date_for_sending')
                        ->label('هل هناك تاريخ للإرسال؟')
                        ->live(),
        
                        DatePicker::make('date_for_sending_yearly')->label('تاريخ الإرسال السنوي')
                            ->nullable()
                            ->live()
                            ->disabled(fn (Get $get): bool => ! $get('is_there_date_for_sending')),
        
                        Select::make('weekly_day')
                        ->label('اليوم الأسبوعي')
                            ->options([
                                'Saturday' => 'Saturday',
                                'Sunday' => 'Sunday',
                                'Monday' => 'Monday',
                                'Tuesday' => 'Tuesday',
                                'Wednesday' => 'Wednesday',
                                'Thursday' => 'Thursday',
                                'Friday' => 'Friday',
                            ])
                            ->nullable()
                            ->live()
                            ->disabled(fn (Get $get): bool => ! $get('is_there_date_for_sending')),
        
                        TimePicker::make('weekly_time')
                            ->label('الوقت الأسبوعي')
                            ->nullable()
                            ->live()
                            ->disabled(fn (Get $get): bool => ! $get('is_there_date_for_sending')),
                        TimePicker::make('weekly_time_sm')
                            ->label('وقت ارسال في السوشيال ميديا')
                            ->nullable()
                            ->live()
                            ->disabled(fn (Get $get): bool => ! $get('is_there_date_for_sending')),
                    ])->columns(3),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('name')->sortable()->searchable(),
                TextColumn::make('importance')->badge(),
                TextColumn::make('category.name')->label('Category'),
                TextColumn::make('location.name')->label('Location'),
                TextColumn::make('tagGroup.name')->label('Tag Group'),
                TextColumn::make('weekly_day')->label('Day'),
                TextColumn::make('weekly_time')->label('Time'),
                TextColumn::make('addedBy.name')->label('Added By'),
                TextColumn::make('updatedBy.name')->label('Updated By'),
                TextColumn::make('created_at')
                    ->label('تاريخ الإضافة'),
                TextColumn::make('updated_at')
                    ->label('آخر تعديل'),
            ])
            ->filters([
                //
            ])
            ->actions([
                Tables\Actions\ViewAction::make(),
                Tables\Actions\EditAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListTags::route('/'),
            'create' => Pages\CreateTag::route('/create'),
            'edit' => Pages\EditTag::route('/{record}/edit'),
        ];
    }
}
