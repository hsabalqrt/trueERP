<?php

namespace App\Filament\Resources;

use App\Filament\Resources\ClientResource\Pages;
use App\Filament\Resources\ClientResource\RelationManagers;
use App\Models\Client;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Forms\Components\Section;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletingScope;
use Filament\Forms\Components\Tabs;

use App\Filament\Resources\ClientResource\Pages\ViewClient;


use Filament\Infolists\Infolist;
use Filament\Infolists\Components\TextEntry;
use Filament\Infolists\Components\Section as InfolistSection;
use Filament\Infolists\Components\Split;
use Filament\Support\Enums\FontWeight;
use Filament\Forms\Get;

use Filament\Tables\Filters\Filter;
use Filament\Tables\Filters\SelectFilter;

use Filament\Tables\Enums\FiltersLayout; //  FiltersLayout

class ClientResource extends Resource
{
    protected static ?string $model = Client::class;

    protected static ?string $navigationIcon = 'heroicon-o-briefcase';
    protected static ?string $navigationGroup = 'CRM';
    protected static ?string $navigationLabel = 'العملاء';
    protected static ?string $pluralLabel = 'العملاء';
    protected static ?string $label = 'عميل';
    protected static ?string $slug = 'clients';
    protected static ?string $recordTitleAttribute = 'name';
    protected static ?string $modelLabel = 'عميل';
    protected static ?string $pluralModelLabel = 'العملاء';
    protected static ?string $modelLabelPlural = 'العملاء';
    protected static ?string $modelLabelSingular = 'عميل';
    protected static ?string $modelLabelSingularPlural = 'العميل';
    protected static ?string $navigationBadge = 'جديد';
    protected static ?string $navigationBadgeColor = 'success';
    protected static ?string $navigationSearch = 'true';
    protected static ?string $navigationSearchPlaceholder = 'ابحث عن عميل...';
    
    public static function form(Form $form): Form
    {
        return $form
            ->schema([
            Tabs::make('Tabs')
            ->columnSpanFull()
                ->tabs([
                    Tabs\Tab::make('البيانات الأساسية')
                        ->icon('heroicon-o-clipboard-document-list')
                        ->schema([
                            // البيانات الأساسية
                            Section::make('البيانات الأساسية')
                                ->schema([
                                    Section::make('')
                                    ->schema([
                                        
                                        Forms\Components\TextInput::make('company')
                                            ->label('الشركة')
                                            ->required(),
                                        Forms\Components\TextInput::make('client_name')
                                            ->label('اسم العميل')
                                            ->nullable(),
                                        Forms\Components\TextInput::make('address')
                                            ->label('العنوان')
                                            ->nullable(),
                                        Forms\Components\TextInput::make('contact_number')
                                            ->label('رقم الاتصال')
                                            ->nullable(),
                                    ])->compact()->columns(2),
                                    Forms\Components\Select::make('location_id')
                                        ->label('الموقع')
                                        ->relationship('location', 'name')
                                        ->searchable()
                                        ->required(),
                                    ]),
                            Section::make('الباقة والاشتراك')
                                ->schema([
                                    Forms\Components\Select::make('package_id')
                                        ->label('الباقة')
                                        ->relationship('package', 'package_type')
                                        ->required(),
                                    Forms\Components\DatePicker::make('date_of_subscription')
                                        ->label('تاريخ الاشتراك')
                                        ->default(now())
                                        ->required()->columns(2),
                                    Forms\Components\TextInput::make('amount')
                                        ->label('المبلغ')
                                        ->numeric()
                                        ->required(),
                                    Forms\Components\Select::make('currency_id')
                                        ->label('العملة')
                                        ->relationship('currency', 'currency_name')
                                        ->required(),
                                    
                                    Forms\Components\TextInput::make('marketing_amount')
                                        ->label('المبلغ التسويقي')
                                        ->numeric()
                                        ->nullable(),
                                    Forms\Components\Select::make('subscription_type')
                                        ->label('نوع الاشتراك')
                                        ->options([
                                            'monthly' => 'شهري',
                                            'annual' => 'سنوي',
                                        ])
                                        ->default('monthly')
                                        ->required(),
                                    Forms\Components\Select::make('payment_type')
                                        ->label('نوع الدفع')
                                        ->options([
                                            'advance' => 'مقدم',
                                            'deferred' => 'آجل',
                                        ])
                                        ->default('advance')
                                        ->required(),
                                    
                                    ])->columns(2),            
                                    
                                    
                            // العلاقات الأخرى
                            Forms\Components\Select::make('client_need_id')
                                ->label('احتياج العميل')
                                ->relationship('clientNeed', 'name')
                                ->required(),
                            Forms\Components\Select::make('category_id')
                                ->label('التصنيف')
                                ->relationship('category', 'name')
                                ->required(),
                        ]),
                    Tabs\Tab::make('الاشعار والتوقيف')
                    ->icon('heroicon-o-chat-bubble-left-right')
                        ->schema([
                            // توقيف
                            // Forms\Components\Toggle::make('status')
                            //     ->label('العميل شغال؟')
                            //     ->onColor('success')
                            //     ->offColor('danger')
                            //     ->onIcon('heroicon-o-check')
                            //     ->offIcon('heroicon-o-x-mark')
                            //     ->inline(false),
                            Forms\Components\TextInput::make('suspension_days')
                                ->label('مدة التوقيف (أيام)')
                                ->numeric()
                                ->nullable()
                                ->live()
                                ->disabled(fn (Get $get): bool => $get('is_credit_allowed')),
                            Forms\Components\Toggle::make('is_credit_allowed')
                                ->label('السقف الائتماني مسموح')
                                ->default(false)
                                ->live()
                                ->reactive()
                                ->afterStateUpdated(function ($state, callable $set) {
                                    if ($state) {
                                        $set('suspension_days', null); // Set field to null
                                    }
                                }),
                            Forms\Components\DateTimePicker::make('suspended_at')
                                ->label('تاريخ التوقيف')
                                ->nullable(),
                            
                        ]),
                    Tabs\Tab::make('التقييم والكليشة')
                    ->icon('heroicon-o-star')
                        ->schema([
                            // التقييم
                            Forms\Components\Select::make('customer_rating_type')
                                ->label('نوع تقييم العميل')
                                ->options([
                                    'automatic' => 'تلقائي',
                                    'manual' => 'يدوي',
                                ])
                                ->default('automatic')
                                ->live()
                                ->required()
                                ->reactive()
                                ->afterStateUpdated(function ($state, callable $set, callable $get) {
                                    if ($state == 'automatic') {
                                        $amount = $get('amount');
                                        $packageId = $get('package_id'); // افترض أن هناك حقل اختيار للحزمة مرتبط بجدول packages
                                        if ($amount && $packageId) {
                                            $package = \App\Models\Package::find($packageId);
                                            if ($package && $package->package_original_price != 0) {
                                                $rating = round(($amount / $package->package_original_price) * 10);
                                                $set('customer_rating_value', $rating);
                                            }
                                        }
                                    }
                                }),

                            Forms\Components\TextInput::make('customer_rating_value')
                                ->label('قيمة التقييم')
                                ->numeric()
                                ->minValue(1)
                                ->maxValue(10)
                                ->live()
                                ->reactive()
                                ->disabled(fn (Get $get): bool => $get('customer_rating_type') === 'automatic')
                                ->nullable(),

                            // الكليشة
                            Forms\Components\TextInput::make('change_cliche_threshold')
                                ->label('كم عدد التصاميم لتغيير الكليشة')
                                ->numeric()
                                ->nullable(),
                        ]),
                    ])->columns(2),
                

                

                



                
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('company')->label('الشركة')->sortable()->searchable(),
                Tables\Columns\TextColumn::make('client_name')->label('اسم العميل')->sortable()->searchable(),
                Tables\Columns\TextColumn::make('location.name')->label('الموقع'),
                Tables\Columns\TextColumn::make('contact_number')->label('رقم الاتصال'),
                Tables\Columns\TextColumn::make('amount')->label('المبلغ')
                ->formatStateUsing(function ($record) {
                    return number_format($record->amount, 2) . ' ' . ($record->currency->currency ?? '');
                }),
                Tables\Columns\TextColumn::make('subscription_type')->label('نوع الاشتراك')
                ->formatStateUsing(function ($state) {
                    return $state === 'monthly' ? 'شهري' : 'سنوي';
                }),
                Tables\Columns\TextColumn::make('payment_type')->label('نوع الدفع')
                ->formatStateUsing(function ($state) {
                    return $state === 'advance' ? 'مقدم' : 'مؤخر';
                }),
                Tables\Columns\BooleanColumn::make('status')->label('حالة العميل'),
            ])
            ->filters([
                    Tables\Filters\Filter::make('active_only')
                        ->label('العملاء النشطين')
                        ->query(fn (Builder $query): Builder => $query->where('status', true))
                        ->toggle(), // هذا يحوله إلى Checkbox

                    Tables\Filters\Filter::make('suspended_only')
                        ->label('العملاء الموقوفين')
                        ->query(fn (Builder $query): Builder => $query->where('status', false))
                        ->toggle(),
                    // Tables\Filters\TernaryFilter::make('status')
                    //     ->label('حالة العميل')
                    //     ->trueLabel('العملاء النشطين')
                    //     ->falseLabel('العملاء الموقوفين')
                    //     ->placeholder('الكل'),
                // Filter::make('status')->label('العملاء النشطين')
                //     ->query(fn (Builder $query): Builder => $query->where('status', true)),
                // Filter::make('status')->label('العملاء الموقفين')
                //     ->query(fn (Builder $query): Builder => $query->where('status', false)),
                // SelectFilter::make('status')
                //     ->multiple()
                //     ->options([
                //         '1' => 'نشط',
                //         '0' => 'موقف',
                //     ]),
            ], layout: FiltersLayout::AboveContent)
            ->actions([
                Tables\Actions\EditAction::make(),
                Tables\Actions\ViewAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function infolist(Infolist $infolist): Infolist
    {
        return $infolist
            ->schema([
                // Split::make([
                //     InfolistSection::make([
                //         TextEntry::make('company')->label('الشركة')
                //             ->weight(FontWeight::Bold),
                //         TextEntry::make('client_name')
                //             ->markdown()
                //             ->prose(),
                //     ])->grow(true),
                //     InfolistSection::make([
                //         TextEntry::make('created_at')
                //             ->dateTime(),
                //         TextEntry::make('updated_at')
                //             ->dateTime(),
                //     ])->grow(false),
                // ])->from('lg')
            ]);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListClients::route('/'),
            'create' => Pages\CreateClient::route('/create'),
            'edit' => Pages\EditClient::route('/{record}/edit'),
            'view' => Pages\ViewClient::route('/{record}'),
        ];
    }
}
