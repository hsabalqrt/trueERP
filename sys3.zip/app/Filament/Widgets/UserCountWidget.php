<?php

namespace App\Filament\Widgets;

use Filament\Widgets\StatsOverviewWidget as BaseWidget;
use Filament\Widgets\StatsOverviewWidget\Stat;
use App\Models\User;
use App\Models\Category;

class UserCountWidget extends BaseWidget
{
    // protected static string $view = 'filament.widgets.user-count-widget';

    // public $userCount; // Declare the public property

    // protected function onMount(): void // Use onMount() or mount()
    // {
    //     $this->userCount = User::count(); // Assign the count to the public property
    // }
    // public function getData(): array
    // {
    //     return [
    //         'userCount' => User::count(),
    //     ];
    // }

    protected function getStats(): array
    {
        return [
            Stat::make('عدد المستخدمين', User::count())
                ->description('إجمالي عدد المستخدمين')
                ->color('success'),
            Stat::make('عدد المستخدمين', Category::count())
                ->description('إجمالي عدد المستخدمين')
                ->color('danger'),
        ];
    }
}