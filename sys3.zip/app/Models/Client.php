<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Client extends Model
{
    use HasFactory;

    protected $fillable = [
        'company',
        'client_name',
        'location_id',
        'address',
        'contact_number',
        'date_of_subscription',
        'currency_id',
        'amount',
        'marketing_amount',
        'subscription_type',
        'payment_type',
        'notified_at',
        'suspension_days',
        'is_credit_allowed',
        'suspended_at',
        'package_id',
        'client_need_id',
        'category_id',
        'customer_rating_type',
        'customer_rating_value',
        'change_cliche_threshold',
        'added_by_user',
        'updated_by_user',
    ];

    // العلاقات

    public function location()
    {
        return $this->belongsTo(Location::class);
    }

    public function currency()
    {
        return $this->belongsTo(Currency::class);
    }

    public function package()
    {
        return $this->belongsTo(Package::class);
    }

    public function clientNeed()
    {
        return $this->belongsTo(ClientNeed::class);
    }

    public function category()
    {
        return $this->belongsTo(Category::class);
    }

    public function addedBy()
    {
        return $this->belongsTo(User::class, 'added_by_user');
    }

    public function updatedBy()
    {
        return $this->belongsTo(User::class, 'updated_by_user');
    }

}
