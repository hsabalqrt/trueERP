<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;


class ClientNeed extends Model
{
    protected $table = 'client_needs';

    protected $fillable = [
        'name',
        'importance_level', // مستوى الأهمية
        'added_by_user',
        'updated_by_user',
    ];

    // علاقة Many-to-Many مع tags_groups
    public function tagsGroups()
    {
        return $this->belongsToMany(TagGroup::class, 'client_need_tags_group', 'client_need_id', 'tags_group_id');
    }

    // (اختياري) علاقة مع التصنيفات
    public function categories()
    {
        return $this->belongsToMany(Category::class, 'category_client_need');
    }

    // ✅ علاقات المستخدم الذي أضاف والسجل الذي عدّله
    public function addedByUser()
    {
        return $this->belongsTo(User::class, 'added_by_user');
    }

    public function updatedByUser()
    {
        return $this->belongsTo(User::class, 'updated_by_user');
    }
}
