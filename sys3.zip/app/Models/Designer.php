<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Designer extends Model
{

    protected $fillable = [
        'user_id',
        'min_capacity',
        'max_capacity',
        'rate',
        'shift_hours',
        'discipline_score',
        'amount_of_designs',
        'freepik_account',
        'pc_number',
    ];
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function categories()
    {
        return $this->belongsToMany(Category::class);
    }
}
