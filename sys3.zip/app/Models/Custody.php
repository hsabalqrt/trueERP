<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;


class Custody extends Model
{

    protected $table = 'custody';

    protected $fillable = [
        'name',
        'user_id',
        'added_by_user',
        'updated_by_user',
    ];

    // علاقات

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function addedBy()
    {
        return $this->belongsTo(User::class, 'added_by_user');
    }

    public function updatedBy()
    {
        return $this->belongsTo(User::class, 'updated_by_user');
    }
}
