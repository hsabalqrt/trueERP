<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;



class TagGroup extends Model
{
    use HasFactory;

    protected $table = 'tags_groups';

    protected $fillable = [
        'name',
        'added_by_user',
        'updated_by_user',
    ];



    // ✅ علاقات المستخدمين
    public function addedByUser()
    {
        return $this->belongsTo(User::class, 'added_by_user');
    }

    public function updatedByUser()
    {
        return $this->belongsTo(User::class, 'updated_by_user');
    }

    // ✅ (اختياري) علاقة مع الوسوم tags إذا كانت موجودة
    public function tags()
    {
        return $this->hasMany(Tag::class);
    }

    public function clientNeeds()
    {
        return $this->belongsToMany(ClientNeed::class, 'client_need_tags_group');
    }
    
}
