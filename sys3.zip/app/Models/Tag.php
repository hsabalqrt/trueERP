<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;


class Tag extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'importance',
        'category_id',
        'location_id',
        'tag_group_id',
        'is_repetition',
        'repetition',
        'weekly_times',
        'monthly_times',
        'yearly_times',
        'is_there_date_for_sending',
        'date_for_sending_yearly',
        'weekly_day',
        'weekly_time',
        'weekly_time_sm',
        'added_by_user',
        'updated_by_user',
    ];


    // العلاقات (اختياري)
    public function category()
    {
        return $this->belongsTo(Category::class);
    }

    public function location()
    {
        return $this->belongsTo(Location::class);
    }

    public function tagGroup()
    {
        return $this->belongsTo(TagGroup::class, 'tag_group_id');
    }

    public function addedBy()
    {
        return $this->belongsTo(User::class, 'added_by_user');
    }

    public function updatedBy()
    {
        return $this->belongsTo(User::class, 'updated_by_user');
    }
}
