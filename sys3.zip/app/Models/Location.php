<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Location extends Model
{

    protected $with = ['addedBy', 'updatedBy'];
    
    protected $fillable = [
        'name',
        'added_by_user',
        'updated_by_user',
    ];

    public function addedBy()
    {
        return $this->belongsTo(User::class, 'added_by_user');
    }

    public function updatedBy()
    {
        return $this->belongsTo(User::class, 'updated_by_user');
    }
}
