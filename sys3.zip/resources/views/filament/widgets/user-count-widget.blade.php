<!-- 
<x-filament::widget>
    <x-filament::card>
        <div class="text-xl font-bold">
            عدد المستخدمين: {{ $userCount }}
        </div>
    </x-filament::card>
</x-filament::widget>

 -->
